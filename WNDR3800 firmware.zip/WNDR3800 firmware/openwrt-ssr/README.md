本项目只提供shadowsocksr和shadowsocks以及redsocks的ipk，以供在明月永在固件上安装使用。请不要在其它固件上安装这些ipk，因为有修改，和固件中其它的文件相互调用，所以不保证在其它固件里安装能正常使用。

SSR需要安装(按顺序)
luci-app-ChinaDNS_1.3.1-1_all.ipk
luci-app-pdnsd_git-***_all.ipk
luci-i18n-pdnsd-zh-cn_git-***-1_all.ipk
luci-app-shadowsocksR-GFW_1.2.2_all.ipk

ss需要安装(按顺序)
luci-app-ChinaDNS_1.3.1-1_all.ipk
luci-app-pdnsd_git-***-1_all.ipk
luci-i18n-pdnsd-zh-cn_git-***-1_all.ipk
Shadowsocks-libev-spec_3.1.0-2_***.ipk
luci-app-shadowsocks-spec_1.3.1-1_all.ipk


其它可在安装完以上任意一组后选装。

