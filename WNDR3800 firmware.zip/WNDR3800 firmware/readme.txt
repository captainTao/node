3800分为两个版本，一个版本的名字有1CHNAS，另外一个没有；

明月版本：2018年2月cc终结版
https://dl.myopenwrt.org/

openwrt: https://openwrt.org/

安装教程
Refer to:
http://www.right.com.cn/forum/thread-139399-1-1.html


里面有三个固件：
淘宝发：(明月)openwrt-mingyue-20150306-14.07-ar71xx-generic-wndr3800-squashfs-sysupgrade
明月最新cc版本： 3800-明月OP-16M
cc版本ss插件：openwrt-ssr
openwrt版本：3800-openwrt




16M固件为 明月版本：2018年2月cc终结版 https://dl.myopenwrt.org/
16M的插件固件： https://github.com/rapistor/




---------update Date:2018/07/24