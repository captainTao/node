# openwrt-scripts
A collection of some useful scripts running on OpenWrt/LEDE routers
